let x = false;

function zegar() {
	const dnityg = ["poniedziałek", "wtorek", "środa", "czwartek", "piątek", "sobota", "niedziela"];
	const miesiace = ["styczeń", "luty", "marzec", "kwiecień", "maj", "czerwiec", "lipiec", "sierpień", "wrzesień", "październik", "listopad", "grudzień"];
	let czas = new Date();
	
	let dzien = blagam(czas.getDate());
	let miesiac = blagam(czas.getMonth());
	let rok = czas.getFullYear();
	let godzina = blagam(czas.getHours());
	let minuta = blagam(czas.getMinutes());
	let sekunda = blagam(czas.getSeconds());
	let mili = blagam(czas.getMilliseconds());
	
	document.getElementById('zegar').innerHTML = dnityg[czas.getDay()-1] + " " +miesiace[miesiac]+" " + godzina + ' : ' 
	 + minuta + ' : '+ sekunda;
	
	setTimeout('zegar()',1000);
}

function odliczanie() {
	let czas = new Date();
	let wakacje = new Date("2023-6-23");
	let time = wakacje-czas;
	
	let dzionek = blagam(Math.floor(time/(24*60*60*1000)));
	let godzinka = blagam(Math.floor(time/(60*60*1000)) - dzionek*24);
	let minutka = blagam(Math.floor(time/(60*1000)) %60);
	let sekundka = blagam(Math.floor(time/1000) % 60);
	
	document.getElementById('minutnik').innerHTML = dzionek + " : " +  godzinka + " : " + minutka + ' : ' + sekundka;
	
	setTimeout("odliczanie()", 1000);
}
function blagam(YOO) {
	if (YOO < 10) {
			YOO = '0' + YOO;
		}
	return YOO;
}

function invoke() {
	zegar();
	odliczanie();
}


