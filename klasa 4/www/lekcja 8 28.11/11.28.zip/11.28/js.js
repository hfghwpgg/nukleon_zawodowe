function zad1() {
	let tab1 = [7, 3, 1, 6, 9, 5, 4, 10, 2, 2];
	console.log(tab1[4]);
	tab1[6] = 12;
	let tab2 = new Array(tab1.length);
	
	let tab3 = new Array(tab1.length);
	tab1.forEach(s);
	function s(item,index,arr) {
		tab3[index] = tab1[index]+tab2[index];
	}
	tab1.forEach((item,index,arr) => {tab2[tab1.length - index - 1] = item});
	console.log(tab1);
	console.log(tab2);
}

function zad2() {
	function odejmo(a,b) {
		return a-b;
	}
	let tab = new Array(3);
	tab.fill(1);
	console.log(tab);
	tab.forEach((item,index,arr) => {tab[index] = parseInt(prompt("podaj liczbe: "))});
	console.log(tab);
	let suma = 0;
	for(let i = 0; i<tab.length; i++) {suma += tab[i]};
	let srednia = suma/tab.length;
	console.log("srednia: ", srednia);
	let ile3 = 0;
	for(let i = 0; i<tab.length; i++) {if (tab[i] === 3) {ile3++}};
	console.log("liczba powtorzen liczby 3: ", ile3);
	tab.sort(odejmo);
	console.log("posortowana: ", tab);
	let mini = [tab[0], tab[1], tab[2]];
	let maks = [tab[tab.length-1],tab[tab.length-2],tab[tab.length-3]];
	console.log("3 najmniejsze: ", mini);
	console.log("3 najwieksze: ", maks);
	tab.forEach((item,index,arr) => {tab[index] = tab[index] * tab[index]});
	console.log("po kwadratowaniu: ", tab);
	let ileparz = 0;
	tab.forEach((item,index,arr) => {if (!(item%2)) {ileparz++}});
	console.log("parzyste: ", ileparz)
	let ilepodz3 = 0;
	tab.forEach((item,index,arr) => {if (!(item%3)) {ilepodz3++}});
	console.log("podzielne przez 3: ", ilepodz3)
	
}

function zad3() {
	const male = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","ą","ę","ż","ź","ć","ó"];
	let tab = new Array(10);
	tab.fill(1);
	//tab = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'];
	tab.forEach((item,index,arr) => {tab[index] = prompt("podaj litere: ")});
	console.log(tab);
	let napis;
	while (true) {
		napis = prompt("podaj napis co ma 10 liter: ");
		if (napis.length === 10 ) {
			break;
		}
		alert("musi miec 10 liter!!")
	}
	tab.forEach((item,index,arr) => {tab[index] = napis[index]})
	console.log("z napisem: ", tab);
	tab.forEach((item,index,arr) => {if (male.includes(item)) {tab[index] = item.toUpperCase()} else {tab[index] = item.toLowerCase()}; });
	console.log("po zamianie liter:", tab);
	let tabrand = new Array(10);
	let tabpomoc = Array.from(tab);
	for(let i = 0; i<10; i++) {
		rr = random(10-i);
		tabrand[i] = tabpomoc[rr];
		tabpomoc.splice(rr,1);
	}
	console.log("losowa kolejnosc: ", tabrand);
}

function zad4() {
	let tab = new Array(100);
	for (let i =0; i<tab.length; i++) {
		tab[i] = random(100);
	}
	console.log(tab);
	let ilemaks = 0;
	const maks = tab.reduce((a, b) => { return Math.max(a, b) });
	tab.forEach((item,index,arr) => {if (item === maks) {ilemaks++}});
	console.log("max liczba: ", maks, ": ", ilemaks, " razy");
	for(let i = 1; i<=tab.length; i+=2) {
		console.log(i, ": ", tab[i]);
	}
	let sum=0;
	for(let i = 5;i < 15; i++) {
		sum += tab[i];
	}
	console.log("suma od 5 do 15: ", sum);
	const min = tab.reduce((a, b) => { return Math.min(a, b) });
	console.log("minimalna liczba: ", min);
	const min_index = tab.indexOf(min);
	console.log("najnizsza liczba i 2 sasiednie: ", tab[min_index-1], tab[min_index], tab[min_index+1]);
	let tab_do10 = new Array();
	tab.forEach((item,index,arr) => {if (item<10) {tab_do10.push(item)}});
	console.log(tab_do10);
	let zadf = [];
	for(let i=0; i<100; i++) {
		let k = 0;
		for(let j=0; j<=i; j++) {
			k += tab[j];
		}
		zadf.push(k);
	}
	console.log(zadf);
}
function zad5() {
	let tab = new Array(100);
	tab.fill(0);
	for(let i=2; i<tab.length; i++) {
		if (tab[i-1] == 0) {tab[i-1]=1};
		tab[i] = tab[i-1] + tab[i-2];
	}
	
	for(let i=1; i<tab.length; i++) {
		tab[i] = tab[i-1] + 3;
	}
	tab.forEach((item,index,arr) => {tab[index]=Math.pow(2, index)})
	console.log(tab);
}

function random(range) {
	return Math.floor(Math.random() * range);
}

zad2();