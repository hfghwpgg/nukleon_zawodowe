function zad1() {
	let a = 21;
	let b = 17;
	alert(a+b);
}

function zad2() {
	let a = '';
	for (let i=1; i<=100; i++) {
		a+= (i + "; ");
	}
	document.getElementById("wynik").innerHTML = a;
}

function invoke() {
	zad1();
	zad2();
}