function zad1() {
	let tab = new Array(10);
	for (let i = 0; i<tab.length; i++) {
		tab[i] = Math.floor(Math.random()*10);
	}
	console.log("tablica: ", tab);
	tab.forEach(e => {if (e%2!=0) {console.log(e)} });
}

function zad2() {
	let tab = [];
	let response;
	while (true) {
		response = prompt("podaj liczbe, aby przerwac wpisz 0")
		if (response == 0) {break}; 
		tab.push(response);
	}
	let str = "";
	tab.forEach(e => str += e + ", " );
	document.getElementById("zad2").innerHTML = str;
}

function zad3() {
	osoby=["jan nowak","kazimierz zyga","stefan koc","ewa mocek","mariusz abramski"];
	let podp_a = "";
	osoby.forEach(e => {podp_a += e + ", "});
	document.getElementById("zad3_1").innerHTML = podp_a;
	let podp_b = "";
	osoby.forEach(str => {let f = str.split(" ");
		podp_b += f[0][0].toUpperCase() + 
		f[0].slice(1,f[0].length) + 
		" " + 
		f[1][0].toUpperCase() + 
		f[1].slice(1,f[1].length) +
		", "}
	);
	document.getElementById("zad3_2").innerHTML = podp_b;
	

}
zad3();