function zad1() {
	let text = "elo daniel";
	console.log(text.length);
}

function zad2() {
	const text2 = "Bardzo lubię jeść marchewkę";
	console.log(text2.split(" ").length);
}

function zad3() {
	let name = "marcin";
	name = name[0].toUpperCase() + name.substr(1);
	console.log(name);
}

function zad4() {
	const email = "loremimpsum@gmail.com";
	if (email.indexOf("@") > 0) {console.log("jest @"); return};
	console.log("nie ma @");
}

function zad5() {
	let text = "Uczę się stringów w C++";
	console.log(text.lastIndexOf("C++"));
	text = text.slice(0, text.lastIndexOf("C++"));
	text += "Javascript";
	console.log(text);
}

function zad6() {
	let text = "Uczę się stringów w C++";
	let url = "http://mojastrona.pl";
	url += "?text=" + encodeURI(text);
	console.log(url);
}

function zad7() {
	const text = "Ala ma kota";
	console.log(text.toLowerCase());
	console.log(text.toUpperCase());
	let text2 = '';
	for (let i = 0; i<= text.length; i++) {
		if (i%2==0) {text2 += text.charAt(i).toUpperCase()} else {text2 += text.charAt(i).toLowerCase()};
	}
	console.log(text2);
	text2 = text.replace("Ala", "Ola");
	console.log(text2);
	console.log(text.substr(text.indexOf("m")), text.length);
}
	

zad7();