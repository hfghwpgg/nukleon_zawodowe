function nwd() {
    let A = parseInt(document.getElementById("liczba_A").value);
    let B = parseInt(document.getElementById("liczba_B").value);
    const bDzialania = document.getElementById("pokaz_dzialania").checked;
    const bKroki = document.getElementById("ilosc_dzialan").checked;
    let dzialania = '<br>';
    let kroki = 0;

    while(A!==B) {
        if (A>B) {
            dzialania += A + " - " + B + '<br>';
            A -= B;
        } else {
            dzialania += A + " - " + B + '<br>';
            B -= A;
        }
        kroki++;
        if (kroki>9999) {console.log("za duzo!"); break};
    }
    let blagam = '';
    blagam += `NWD tych dwóch liczb to: ${A} <br>`;
    bKroki ? blagam += `liczba kroków: ${kroki} <br>` : null;
    bDzialania ? blagam += `kroki: ${dzialania}` : null;
    document.getElementsByClassName("panel prawy")[0].innerHTML = blagam;
    

}