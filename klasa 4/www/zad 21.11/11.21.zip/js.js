function zad1() {
	const liczba1 = 216.7621;
	let liczba2 = Math.floor(liczba1).toFixed(2);
	let liczba3 = (liczba1 - Math.floor(liczba1)).toFixed(2);
	console.log(liczba2);
	console.log(liczba3);
}

function random(min,max) {
	let asd;
	while (true) {
		asd = Math.random()*max;
		if (asd >= min) {return asd};
	}
}

function zad2() {
	for (let i = 0; i<6; i++) {
		console.log(random(1,49));
	}
}

function zad3() {
	let r;
	while (true) {
		r = prompt("podaj promien: ");
		if (r>0) {
			break;
		}
		alert("promien nie moze byc ujemny!!")
		}
	console.log("pole: ", r*r*Math.PI);
	console.log("obw: ", 2*Math.PI*r);
	
}

function zad4(a,b) {
	let c;
	while(b!=0) {
		c=b;
		b=a%b;
		a=c;
	}
	console.log("NWD to: ", a);
}

zad1();
zad2();
zad3();
zad4(32,24);