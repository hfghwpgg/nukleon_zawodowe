function zad1() {
	let a = parseInt(document.getElementById("jeden").value);
	let b = parseInt(document.getElementById("dwa").value);
	if (a>b) {
		alert(a);
	} else {
		alert(b);
	}
}

function zad2() {
	let a = parseInt(document.getElementById("jeden1").value);
	let b = parseInt(document.getElementById("dwa1").value);
	let c = parseInt(document.getElementById("trzy1").value);
	
	let wynik = a*b*c;
	if (wynik >=0) {
		alert("znak to +");
	} else {
		alert("znak to -");
	}
}
function zad3() {
	let a = parseInt(document.getElementById("jeden").value);
	let b = parseInt(document.getElementById("dwa").value);
	
	let mniejsza;
	let NWD;
	let i=1;
	if (a<b) {mniejsza = a} else {mniejsza=b};
	
	while (i <= mniejsza) {
		if (a%i == 0 && b%i == 0) {
			NWD = i;
		}
		i++;			
	}
	alert(NWD);
}
