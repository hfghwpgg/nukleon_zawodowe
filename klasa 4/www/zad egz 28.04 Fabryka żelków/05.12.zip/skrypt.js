const ksztalty = ["miś", "żabka", "serce"];

function zamow() {
    const ksztalt = parseInt(document.getElementById("ffff").value);
    let text;
    if (ksztalt>0 && ksztalt < 4) {text = ksztalty[ksztalt-1]} else {text='inny kształt'}
    document.getElementById("ksztalt").innerHTML = `Zamowileś żelka: ${text}`
}
function zmien_kolor() {
    const R = document.getElementById("r").value;
    const G = document.getElementById("g").value;
    const B = document.getElementById("b").value;
    document.getElementById('kolor').style.backgroundColor = `rgb(${R}, ${G}, ${B})`
}