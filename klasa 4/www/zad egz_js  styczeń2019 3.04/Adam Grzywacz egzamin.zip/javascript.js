const ceny = [5, 6, 7];

function oblicz_cene() {
  const numer = document.getElementById("nr_kawy").value;
  const waga = document.getElementById("waga_dag").value;
  let cena_koncowa = 0;
  if (numer >= 1 && numer <= 3) {
    cena_koncowa = ceny[numer - 1] * waga;
  }
  document.getElementById(
    "final"
  ).innerHTML = `Koszt zamówienia wynosi ${cena_koncowa} zł`;
}
