function check(num1, num2) {
	if (num1 == 'NaN')  {
		alert("uzupelnij pole nr 1");
		return false;
	}
	if (num2 == 'NaN') {
		alert("uzupelnij pole nr 2");
		return false;
	}
	return true;
}

function dodawanie() {
	let a = parseInt(document.getElementById("jeden").value) || 'NaN';
	let b = parseInt(document.getElementById("dwa").value) || 'NaN';
	if (check(a,b)) {
		let wynik = a+b;
		document.getElementById("wynik").innerHTML = "wynik to: " + wynik;
		return wynik;
	}
	
}

function odejmowanie() {
	let a = parseInt(document.getElementById("jeden").value) || 'NaN';
	let b = parseInt(document.getElementById("dwa").value) || 'NaN';
	if (check(a,b)) {
		let wynik = a-b;
		document.getElementById("wynik").innerHTML = "wynik to: " + wynik;
		return wynik;
	}
}

function mnozenie() {
	let a = parseInt(document.getElementById("jeden").value) || 'NaN';
	let b = parseInt(document.getElementById("dwa").value) || 'NaN';
	if (check(a,b)) {
		let wynik = a*b;
		document.getElementById("wynik").innerHTML = "wynik to: " + wynik;
		return wynik;
	}
}

function dzielenie() {
	let a = parseInt(document.getElementById("jeden").value) || 'NaN';
	let b = parseInt(document.getElementById("dwa").value) || 'NaN';
	if (check(a,b)) {
		if (b == 0) {
			alert("nie mozna dzielic przez 0!!!");
			return false;
		}
		let wynik = a/b;
		document.getElementById("wynik").innerHTML = "wynik to: " + wynik;
		return wynik;
	}
}

function potega() {
	let a = parseInt(document.getElementById("liczbapotegowana").value) || 'NaN';
	let b = document.getElementById("wykladnik").value || 'NaN';
	let wynik = a;
	console.log(b);
	if (b<0) {
		alert("wykładnik musi być dodatni!!!");
	}
	if (b == 0 && a !== 'NaN') {
		wynik = 1;
		document.getElementById("wynik").innerHTML = "wynik to: " + wynik;;
		return;
	}
	if (check(a,b) && b > 0 && b%1 == 0) {
		for (var i = 1; i<b; i++) {
			wynik *=  a;
		}
		document.getElementById("wynik").innerHTML = "wynik to: " + wynik;;
	}
	
	return wynik
}
