<!DOCTYPE html/>
<html lang='pl'>
<head>
	<meta name='charset' content='utf-8'/>
	<meta name='author' content='Adam Grzywacz'/>
	<script src='./js.js'> </script>
	<link rel='stylesheet' href='css.css'/>
</head>
<body>
	<a href='./index.html'> <img src='./banner.jpg'></img></a>
	<h1> POTEGOWANIE </h1>
	<form>
		<label for='liczbapotegowana' > Podaj liczbe: </label>
		<input type='number' id='liczbapotegowana'> </input> <br>
		<label for='wykladnik' > Podaj dodatni, całkowity wykładnik potęgi: </label>
		<input type='number' id='wykladnik'> </input> <br>
		<button type='button' onclick='potega()'> POTEGOWANIE</button>
	</form>
	<div id='wynik' > WYNIK TUTAJ </div>
</body>

</html>