function zad1() {
	var a = 2;
	var b = 3;
	var c = 4;
	if (a>b && a>c) {
		document.getElementById('zad1').innerHTML = a;
	} else if (b>c) {
		document.getElementById('zad1').innerHTML = b;
	} else {
		document.getElementById('zad1').innerHTML = c;
	}
}
function zad2() {
	var elo = document.getElementById('zad2in').value;
	var wiadomosc = "liczba jest: ";
	if (elo>100) {
		wiadomosc = wiadomosc + "jest wieksza od 100, ";
	}
	if (elo%3==0) {
		wiadomosc = wiadomosc + "jest podzielna przez 3";
	}
	document.getElementById('zad2').innerHTML = wiadomosc;
}
function zad3() {
	var wzrost = document.getElementById('zad3in').value;
	if (wzrost < 150) {
		document.getElementById('zad3').innerHTML = "NISKI";
	} else if (wzrost > 180) {
		document.getElementById('zad3').innerHTML = "WYSOKI";
	} else {
		document.getElementById('zad3').innerHTML = "SREDNI";
	}
}