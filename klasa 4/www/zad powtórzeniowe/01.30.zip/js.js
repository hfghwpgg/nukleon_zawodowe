let osoby=["Jan Nowak","Kazimierz Zyga","Stefan Koc","Ewa Mocek","Mariusz Abramski"];
osoby.reverse();
console.log(osoby);

osoby=["Jan Nowak","Kazimierz Zyga","Stefan Koc","Ewa Mocek","Mariusz Abramski"];
let test = '';
let test2 = '';
for(let i = 0; i<osoby.length; i++) {
	test += osoby[i] + ", ";
	test2 += osoby[i] + "<br>";
}
document.getElementById('zad2').innerHTML = test;
document.getElementById('zad3').innerHTML = test2;

osoby=["Jan Nowak","Kazimierz Zyga","Stefan Koc","Ewa Mocek","Mariusz Abramski"];
let osobyImiona = [];
for (let i = 0; i<osoby.length; i++) {
	osobyImiona[i] = osoby[i].slice(0, osoby[i].indexOf(" "));
}
console.log("imiona osob: ", osobyImiona);

osoby=["Jan Nowak","Kazimierz Zyga","Stefan Koc","Ewa Mocek","Mariusz Abramski"];
for (let i = 0; i<osoby.length; i++) {
	let imie_dl = osoby[i].slice(0,osoby[i].indexOf(" ")).length;
	let nazwisko_dl = osoby[i].slice(osoby[i].indexOf(" ")+1, osoby[i].length).length;
	
	osoby[i] = String('a'.repeat(imie_dl) + " " + 'b'.repeat(nazwisko_dl));
}
console.log(osoby)

osoby=["Jan Nowak","Kazimierz Zyga","Stefan Koc","Ewa Mocek","Mariusz Abramski"];
osoby.reverse();
console.log(osoby.pop(), osoby.pop());
osoby.reverse();
console.log(osoby);

osoby=["Jan Nowak","Kazimierz Zyga","Stefan Koc","Ewa Mocek","Mariusz Abramski"];
osoby.splice("Ewa Mocek",1);
osoby.push("Maria Kapik");
osoby.push("Elżbieta Konf");
console.log(osoby);

let tekst = "JavaScript jest językiem programowania od zawsze związanym z tworzeniem aplikacji WWW.";
let slowa = tekst.split(' ');
console.log(slowa);
for (let j = 1; j<slowa.length+1; j++) {
	let id = 'zad7_'+j;
	document.getElementById(id).innerHTML = slowa[j-1];
	document.getElementById(id).style.backgroundColor = 'yellow';
}

// FUNKCJE (METODY) TEKSTOWE

let s = "JavaScript (w skrócie JS) – język został opracowany przez firmę Netscape w połowie lat 90. Jego twórcę jest Brendan Eich.";

document.getElementById("informacja").innerHTML = s;
document.getElementById("dane").innerHTML = s.length + " znaków";
document.getElementById("informacja1").innerHTML = s.substr(22,2);
document.getElementById("informacja2").innerHTML = s;
document.getElementById("dane1").innerHTML = s.substring(42,72);
s = s.replace("Netscape", "Netscape Communications Corporation");
console.log(s);
document.getElementById("dane2").innerHTML = s;
console.log(s.split(" "));
document.getElementById("dane3").innerHTML = s.toUpperCase();
document.getElementById("informacja4").innerHTML = s;
document.getElementById("dane4").innerHTML = s.toLowerCase();
document.getElementById("informacja5").innerHTML = s;
document.getElementById("dane5").innerHTML = "słowo netscape za czyna sie od: " + s.indexOf("N") + " znaku";
document.getElementById("dane6").innerHTML = "ostatnia spacja to znak nr: " + s.lastIndexOf(" ");

