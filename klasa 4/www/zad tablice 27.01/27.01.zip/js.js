function zad1() {
	let tab1 = [7, 3, 1, 6, 9, 5, 4, 10, 2, 2];
	console.log("tab1: ", tab1);
	console.log("5 element tab1: ", tab1[4]);
	tab1[6] = 12;
	let tab2 = new Array(tab1.length);
	tab1.forEach((e,i) => tab2[i] = e);
	console.log("tab2: ", tab2);
	let tab3 = new Array(tab1.length); 
	tab1.forEach((e,i) => {tab3[i] = tab2[i] + tab1[i]});
	console.log("tab3: ", tab3);
	tab1.forEach((e,i) => tab2[tab2.length-i-1] = e);
	console.log("odwrocony tab2: ", tab2);
	tab1.sort((a,b) =>  a - b);
	console.log("posortowane tab1: ", tab1);
}

function zad2() {
	let tab1 = new Array(100);
	for (let i = 0; i<100; i++) {
		tab1[i] = Math.floor(Math.random()*100);
	}
	console.log("randomowa tablica: ", tab1);
	const maks = Math.max(...tab1);
	let ile_maks = 0;
	tab1.forEach((e,i) => {if(tab1[i] === maks) {ile_maks++}});
	console.log("najwieksza liczba w tabeli: ", maks, " razy: ", ile_maks );
	let tab2 = [];
	tab1.forEach((e,i) => {if(i%2!=0) {tab2.push(e)}});
	console.log("tablica z nieparzystymi indexami: ", tab2);
	let male_liczby = 0;
	tab1.forEach(e => {if (e>= 5 && e<15) {male_liczby++}});
	console.log("liczb w przedziale <5;15) jest: ", male_liczby);
	const min = tab1.reduce((a,b) => Math.min(a,b));
	console.log("najmniejsza liczba: ", min);
	console.log("najmniejsza liczba i jej sąsiedzi: ", tab1[tab1.indexOf(min)-1], tab1[tab1.indexOf(min)], tab1[tab1.indexOf(min)+1]);
	let tab3 = [];
	tab1.forEach(e => {if(e>10) {tab3.push(e)}});
	console.log("tablica liczb wiekszych od 10: ", tab3);
	let zadf = [];
	for(let i=0; i<100; i++) {
		let k = 0;
		for(let j=0; j<=i; j++) {
			k += tab1[j];
		}
		zadf.push(k);
	}
	console.log("tablica taka co w zadaniu F: ", zadf);
}

function zad3() {
	let tabFib = [1,1,1];
	let tab2do2 = [1];
	let tab3 = [3];
	let tab2m2 = [2];
	for (let i = 2; i<100; i++) {
		tabFib[i] = tabFib[i-1] + tabFib[i-2];
	}
	for (let i = 1; i<100; i++) {
		tab2do2[i] = Math.pow(2,i);
		tab3[i] = 3*(i+1);
		tab2m2[i] = tab2m2[i-1]*2;
	}
	console.log("ciag Fibonacciego", tabFib);
	console.log("potegi 2: ", tab2do2);
	console.log("mnozenie 3: ", tab3);
	console.log("mnozenie 2: ", tab2m2);
}

zad3();