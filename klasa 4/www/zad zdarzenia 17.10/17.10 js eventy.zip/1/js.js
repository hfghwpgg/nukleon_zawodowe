function klikme() {
	console.log('Klik!');
}
function focusonme() {
	console.log('Najechany!');
}
function backtome() {
	console.log('Jeszcze tu wrocisz!');
}
document.addEventListener("DOMContentLoaded", function(event) {
const element = document.querySelector('#kontener');
element.addEventListener('click', klikme);
element.addEventListener('mouseover', focusonme);
element.addEventListener('mouseout', backtome)
});