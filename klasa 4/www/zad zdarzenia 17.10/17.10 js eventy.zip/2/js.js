const font_size = '20';
function randomColor() {
	const charSet = '0123456789abcdef';
	let col = '#';
	for (let i=0;i<6;i++ ) {
		col += charSet[Math.floor(Math.random()*16)];
	}
	return col;
}

function klikme() {
	console.log('a');
	document.getElementById("kontener").style.backgroundColor = randomColor();
}
function focusonme() {
	document.getElementById("kontener").style.fontSize  = 2 * font_size + 'px';
}
function backtome() {
	document.getElementById("kontener").style.fontSize  = font_size + 'px';
}
document.addEventListener("DOMContentLoaded", function(event) {
const element = document.querySelector('#kontener');
element.addEventListener('click', klikme);
element.addEventListener('mouseover', focusonme);
element.addEventListener('mouseout', backtome);
});