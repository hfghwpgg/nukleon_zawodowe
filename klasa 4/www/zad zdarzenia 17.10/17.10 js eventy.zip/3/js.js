function dblklikme() {
	document.getElementsByClassName("wyroznione")[0].innerHTML = 'Otwocki';
}
function focusonme() {
	console.log(document.getElementsByClassName("wyroznione")[0].innerHTML);
}
document.addEventListener("DOMContentLoaded", function(event) {
const element = document.querySelector('.wyroznione');
element.addEventListener('dblclick', dblklikme);
element.addEventListener('mouseover', focusonme);
});