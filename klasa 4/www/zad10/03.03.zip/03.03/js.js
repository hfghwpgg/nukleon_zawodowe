function zmien_tlo_y() {
	document.body.style.backgroundColor = "yellow";
}
function zmien_tlo_g() {
	document.getElementById("zad2").style.backgroundColor = "green";
}
function zmien_tlo_r() {
	document.getElementById("zad2").style.backgroundColor = "red";
}
function zmien_div() {
	let cyferka = document.getElementById('zad3').value;
	document.getElementById("zad3_2").style.height = cyferka + "px";
	document.getElementById("zad3_2").style.width = cyferka + "px";
	document.getElementById("zad3_1").innerHTML = ", aktualnie: "+cyferka + " px";
}
function zmien_cz() {
	let cyferka = document.getElementById('zad4').value;
	document.getElementById("zad4_1").innerHTML = cyferka;
	document.getElementById("zad4_1").style.fontSize = cyferka + "px";
}

function zad5_init() {
	document.write("<input type='range' min='0' max='255' value='0' id='zad5'/>");
	document.body.style.backgroundColor = 'black';
	document.getElementById("zad5").addEventListener("change", zad5);
}


function zad5() {
	document.body.style.backgroundColor = "rgb(" + (document.getElementById("zad5").value).toString() + ", 0 ,0";
}

function zad6() {
	document.getElementById("zad6").style.backgroundColor = "rgb(" + 
	(document.getElementById("zad6_r").value).toString() + "," +
	(document.getElementById("zad6_g").value).toString() + "," +
	(document.getElementById("zad6_b").value).toString() + ")";
}

function zad7(id) {
	console.log(document.getElementById(id).style.color);
}

document.getElementById("zad1").addEventListener("click", zmien_tlo_y);
document.getElementById("zad2_2").addEventListener("click", zmien_tlo_g);
document.getElementById("zad2_1").addEventListener("click", zmien_tlo_r);
document.getElementById("zad3").addEventListener("change", zmien_div);
document.getElementById("zad4").addEventListener("change", zmien_cz);
// zad5 robi sie w zad5_init
document.getElementById("zad6_r").addEventListener("change", zad6);
document.getElementById("zad6_g").addEventListener("change", zad6);
document.getElementById("zad6_b").addEventListener("change", zad6);
document.getElementById("zad7_1").addEventListener("click", () => zad7('zad7_1'));
document.getElementById("zad7_2").addEventListener("click", () => zad7('zad7_2'));
document.getElementById("zad7_3").addEventListener("click", () => zad7('zad7_3'));