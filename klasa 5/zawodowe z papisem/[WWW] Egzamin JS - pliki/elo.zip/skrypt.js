function sprawdzcene() {
    const cennik = {piling: 45, maska: 30, masaz: 20, regulacja: 5};
    const piling = document.querySelector("#Piling").checked;
    const maska = document.querySelector("#Maska").checked;
    const masaz = document.querySelector("#Masaz").checked;
    const regulacja = document.querySelector("#Regulacja").checked;

    let cena = 0;
    piling ? cena += cennik.piling : null;
    maska ? cena += cennik.maska : null;
    masaz ? cena += cennik.masaz : null;
    regulacja ? cena += cennik.regulacja : null;

    document.querySelector('#wynik').innerHTML = `Cena zabiegów: ${cena} zł`;
}