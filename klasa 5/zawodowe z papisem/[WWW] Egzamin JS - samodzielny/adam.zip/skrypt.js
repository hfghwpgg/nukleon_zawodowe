function Policz() {
    const powierzchnia = document.querySelector("#powierzchnia").value;
    const wynik = Math.ceil(powierzchnia/4);
    document.querySelector("#wynik").innerHTML = `Liczba potrzebnych puszek to: ${wynik}`;
}