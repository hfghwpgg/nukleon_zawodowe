<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>rozgrywki futbolowe</title>
    <link rel="stylesheet" href="styl.css">
</head>
<?php
    $baza = new mysqli("localhost", "root", "", "egzamin");
?>
<body>
    <section id="banner">
        <h2>Światowe rozgrywki piłkarskie</h2>
        <img src="./obraz1.jpg" alt="boisko"/>
    </section>
    <section class="mecze">
    <?php
        $zapytanie1 = "SELECT * FROM rozgrywka";
        $wynik1 = mysqli_query($baza, $zapytanie1);
        while ($row = mysqli_fetch_row($wynik1)) {
            echo "<section class='info'> 
                <h3>". $row[1]. " - ". $row[2] ." </h3>
                <h4>". $row[3] ." </h4>
                <p> ". $row[4] ." </p>
            </section> ";
        }
    ?>
    </section>
    <section class="glowny"><h2>Reprezentacja Polski</h2></section>
    <section class="lewy">
        <p>Podaj pozycje zawodnikow (1-bramkarze, 2-obrońcy, 3-pomocnicy, 4-napastnicy)</p>
        <form action="#" method="post">
            <input type="number" name="pozycja" id="pozycja">
            <input type="submit" value="Sprawdź">
        </form>
        <ul>
            <?php
                if (isset($_POST["pozycja"]) && $_POST["pozycja"] !== "") {
                    $numerek = $_POST["pozycja"];
                    $zapytanie2 = "SELECT imie, nazwisko FROM zawodnik WHERE pozycja_id=$numerek";
                    $wynik2 = mysqli_query($baza, $zapytanie2);
                    while ($row = mysqli_fetch_row($wynik2)) {
                        echo "<li>". $row[0] . " " . $row[1]. "</li>";
                    }
                }
            ?>
        </ul>
    </section>
    <section class="prawy">
        <img src="./zad1.png" alt="piłkarz"/>
        <p>Autor: Adam Grzywacz 42036069doritos</p>
    </section>
</body>
<?php
    $baza -> close();
?>
</html>