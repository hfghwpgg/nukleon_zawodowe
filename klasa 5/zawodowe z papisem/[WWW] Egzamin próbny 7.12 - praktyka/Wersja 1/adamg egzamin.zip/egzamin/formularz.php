<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dane osobowe</title>
    <link rel="stylesheet" href="style.css">
</head>


<body>
    <section id="baner">
        <h3>Dane osobowe pracownikow</h3>
    </section>
    <section id="kontener">
        <section id="lewo">
            <ul>
                <li><a href="index.php">Wyświetl dane</a></li>
                <li><a href="formularz.php">Wpisz dane</a></li>
            </ul>
        </section>
        <section id="prawo">
            <h2>Podaj dane</h2>
            <form action="#" method="post">
                <label for="nazwisko">Nazwisko:</label> <br>
                <input type="text" name="nazwisko" id="nazwisko"><br>
                <label for="imie">Imie:</label> <br>
                <input type="text" name="imie" id="imie"><br>
                <label for="PESEL">PESEL:</label> <br>
                <input type="text" name="PESEL" id="PESEL">
                <input type="submit" value="Sprawdź i zapisz">
            </form>

            <section id="wynik">
                <?php
                $db = new mysqli("localhost", "root", "", "firma");
                $ok = true;
                if (!isset($_POST["nazwisko"]) || strlen($_POST["nazwisko"]) < 1) {
                    echo "<p>brak nazwiska</p>";
                    $ok = false;
                }
                if (!isset($_POST["imie"]) || strlen($_POST["imie"]) < 1) {
                    echo "<p>brak imienia</p>";
                    $ok = false;
                }
                if (!isset($_POST["PESEL"]) || strlen($_POST["PESEL"]) < 1) {
                    echo "<p>brak numeru PESEL</p>";
                    $ok = false;
                } else {
                    if (strlen($_POST["PESEL"]) != 11) {
                        echo "<p>PESEL ma niewłaściwą długość</p>";
                        $ok = false;
                        goto essa;
                    }
                    $cos = [1, 3, 7, 9];
                    $S = 0;
                    for ($i = 0; $i < strlen($_POST["PESEL"]) - 1; $i++) {
                        $S += intval($_POST["PESEL"][$i]) * $cos[$i % 4];
                    }
                    // echo $S;
                    $M = $S % 10;

                    if (($M == 0 && intval($_POST["PESEL"][10]) != $M)
                        || ($M != 0 && intval($_POST["PESEL"][10]) != 10 - $M)
                    ) {
                        echo "<p> PESEL jest nieprawidłowy </p>";
                        $ok = false;
                    }
                }
                essa:
                if ($ok) {
                    echo "<p> zapisuje do bazy " . $_POST["nazwisko"] . " " . $_POST["imie"] . " " . $_POST["PESEL"] . " " . "</p>";
                    $query = "INSERT INTO pracownicy (nazwisko, imie, PESEL) VALUES ('" . $_POST["nazwisko"] . "','" . $_POST["imie"] . "','" . $_POST["PESEL"] . "')";
                    mysqli_query($db, $query);
                }


                ?>
            </section>
        </section>
    </section>
    <section id="stopka">
        <h5>AUTOR strony: adamg 42036069doritos</h5>
    </section>
</body>

</html>