<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dane osobowe</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <section id="baner">
        <h3>Dane osobowe pracownikow</h3>
    </section>
    <section id="kontener">
        <section id="lewo">
            <ul>
                <li><a href="index.php">Wyświetl dane</a></li>
                <li><a href="formularz.php">Wpisz dane</a></li>
            </ul>
        </section>
        <section id="prawo">
            <h2>Dane osobowe</h2>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Nazwisko</th>
                    <th>Imie</th>
                    <th>PESEL</th>
                </tr>
                <?php
                $db = new mysqli("localhost", "root", "", "firma");
                $query = "SELECT * FROM pracownicy WHERE 1";
                $wynik = mysqli_query($db, $query);
                while ($dana = mysqli_fetch_assoc($wynik)) {
                    echo "<tr>
                    <td>" . $dana["id"] . "</td>
                    <td>" . $dana["nazwisko"] . "</td>
                    <td>" . $dana["imie"] . "</td>
                    <td>" . $dana["PESEL"] . "</td>
                </tr>";
                }
                mysqli_close($db);
                ?>
            </table>
        </section>
    </section>
    <section id="stopka">
        <h5>AUTOR strony: adamg 42036069doritos</h5>
    </section>
</body>

</html>