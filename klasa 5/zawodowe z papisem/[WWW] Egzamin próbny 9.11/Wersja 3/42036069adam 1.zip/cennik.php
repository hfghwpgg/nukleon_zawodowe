<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Wynajem pokoi</title>
    <link rel="stylesheet" href="styl2.css" />
</head>

<body>
    <section id="banner">
        <h1>Pensjonat pod dobrym humorem</h1>
    </section>
    <section id="kontener">
        <section id="lewo">
            <a href="index.html">GŁÓWNA</a>
            <img src="1.jpeg" alt="pokoje" />
        </section>
        <section id="srodek">
            <a href="kalkulator.html">CENNIK</a>
            <table>
                <?php
                $db = new mysqli('localhost', 'root', '', 'wynajem');
                $query = "SELECT * FROM pokoje";
                $res = mysqli_query($db, $query);
                $num = mysqli_num_rows($res);
                for ($i = 0; $i < $num; $i++) {
                    $arr = mysqli_fetch_array($res);
                    echo "<tr> 
                    <td>" . $arr["id"] . "</td>
                    <td>" . $arr["nazwa"] . "</td>
                    <td>" . $arr["cena"] . "</td>
                    </tr>";
                }
                mysqli_close($db);
                ?>
            </table>
        </section>
        <section id="prawo">
            <a href="cennik.php">KALKULATOR</a>
            <img src="3.jpeg" alt="pokoje" />
        </section>
    </section>
    <section id="stopka">
        <p>Strone opracował: 42036069doritos</p>
    </section>
</body>

</html>