for (let i = 0; i < 10; i++) {
    console.log(`To jest informacja numer ${i}`);
}

const myBool = true;
const myString = "elo";
const myInt = 1;
const myObject = {adam: "grzywacz"};

function kalkulator(a,b,o) {
    switch (o) {
        case "+": {console.log(a+b); break;};
        case "-": {console.log(a-b); break;};
        case "*": {console.log(a*b); break;};
        case "/": {console.log(a/b); break;};
        default: {console.log("ZLY ZNAK"); break;};
    }
}

const butelka = {
    kolor: "biała",
    zawartosc: "sprite",
    pojemnosc: 100,
    czyOtwarta: true,
    oproznij: function (ile) {
        if (this.pojemnosc - ile > 100) {
            console.log("ZA DUZO ULEWASZ");
            return;
        }
        this.pojemnosc -= ile;
        console.log(this.pojemnosc);
    },
    napelnij: function(ile) {
        if (this.pojemnosc + ile > 100) {
            console.log("ZA DUZO WLEWASZ");
            return;
        }
        this.pojemnosc += ile;
        console.log(this.pojemnosc);
    }
}
document.querySelectorAll("form:not(#hotdogi)").forEach(e => {
    const input = e[0];
    input.addEventListener("input", () => {
        const cena = input.value;
        const obj = e.querySelector("#c");
        obj.innerHTML = cena;
        if (cena < 6) {
            obj.style.backgroundColor = 'green';
        } else if (cena < 7) {
            obj.style.backgroundColor = 'yellow';
        } else {
            obj.style.backgroundColor = 'red';
        }
    })
})

const hot = document.querySelector("#hotdogi");
hot.addEventListener("change", () => {
    let cena = parseInt(hot.querySelector("select#paruwa").value);
    hot.querySelectorAll("input").forEach(e => {
        if (e.checked) {
            cena += parseInt(e.value);
        }
    })
    document.querySelector("#naleznosc").textContent = cena;
})


