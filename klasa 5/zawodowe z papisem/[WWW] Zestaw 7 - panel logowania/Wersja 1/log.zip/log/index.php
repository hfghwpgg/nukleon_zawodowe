<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<?php
    session_start();
    if (isset($_SESSION["login"])) {
        echo "jestes zalogowany jako ".$_SESSION["login"];
    } else {
        echo "nie jestes zalogowany!!";
    }
?>
<style>
body {
    background-image: url("https://www.dhm.de/fileadmin/medien/lemo/Titelbilder/95005813.jpg");
    background-repeat: repeat-y;
    background-size: cover;
}
a {
    background-color: rgba(0, 0, 0, .5);
    color: red;
}
    </style>
<body>
<br>
    <a href="logowanie.php">logowanie</a> <br>
    <a href="rejestracja.php">rejestracja</a><br>
    <a href="wyloguj.php">wyloguj</a><br>
</body>
</html>