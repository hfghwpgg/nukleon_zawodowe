<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<?php
$baza = new mysqli("localhost", "root", "", "adagrz");
if (isset($_POST["login"]) && isset($_POST["haslo"]) && isset($_POST["haslo2"])) {
    $l = $_POST["login"];
    $h = $_POST["haslo"];
    $h2 = $_POST["haslo2"];
    $zapytanie = "INSERT INTO login VALUES ('$l', '$h')";
    if (strlen($l) > 3 && strlen($h) > 3) {
        if ($h !== $h2) {
            echo "hasla sie niezgadzaja!!!";
        } else {
            $wynik = mysqli_query($baza, $zapytanie);
            $_POST = array();
            echo "pomyslna rejestracja!<br>";
            echo "mozesz wrocic na strone glowna i sie zalogowac";
        }
    } else {
        echo "login lub haslo za krotkie";
    }
} else {
    echo "nie wprowadzono wszystkich danych";
}

mysqli_close($baza);
?>
<body>
    <br>
    <h1><a href="index.php">powrot</a></h1>
    <form action="rejestracja.php" method="post">
        <label for="login">login: </label>
        <input type="text" name="login" id="haslo"> <br>
        <label for="haslo">haslo: </label>
        <input type="password" name="haslo" id="haslo"> <br>
        <label for="haslo">powtorz haslo: </label>
        <input type="password" name="haslo2" id="haslo2"> <br>
        <input type="submit" value="rejestruj">
    </form>
</body>
</html>