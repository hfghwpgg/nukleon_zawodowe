<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<?php
session_start();
    $baza = new mysqli("localhost", "root", "", "adagrz");
    if (isset($_POST["login"])) {
        $l = $_POST["login"];
        $h = $_POST["haslo"];
        try {
            $zapytanie = "SELECT haslo FROM login WHERE login LIKE '$l'";
            $wynik = mysqli_query($baza, $zapytanie);
            $wynik = mysqli_fetch_assoc($wynik)["haslo"];
            if ($h === $wynik) {
                $_SESSION["login"] = $_POST["login"];
                //echo "jestes zalogowany jako ". $_SESSION["login"];
                header("Location: index.php");
            } else {
                echo "niepoprawne haslo";
            }
        } catch (Exception $ex) {
            echo "nie znaleziono uzytkownika";
        }

    } else {
        echo "elo";
    }
mysqli_close($baza);


?>
<body>
    <form action="logowanie.php" method="post">
        <label for="login">login: </label>
        <input type="text" name="login" id="login"> <br>
        <label for="haslo">haslo: </label>
        <input type="password" name="haslo" id="haslo"> <br>
        <input type="submit" value="loguj">
        <!-- <input type="button" value="wyloguj" formaction="/wyloguj.php"> -->
    </form>
</body>
</html>